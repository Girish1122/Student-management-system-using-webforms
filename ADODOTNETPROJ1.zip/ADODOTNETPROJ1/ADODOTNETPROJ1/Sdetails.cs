﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class Sdetails : Form
    {
        public Sdetails()
        {
            InitializeComponent();
        }

        private void Sdetailscs_Load(object sender, EventArgs e)
        {
            StaffLogic ob = new StaffLogic();
            dataGridView1.DataSource = ob.getStaffDetails();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 ob = new Form2();
            ob.Show();
            this.Hide();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Hide();
        }

        private void aPPLICATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffSearch ob = new StaffSearch();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffUpdate ob = new StaffUpdate();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffDelete ob = new StaffDelete();
            ob.Show();
            this.Hide();
        }
    }
}
