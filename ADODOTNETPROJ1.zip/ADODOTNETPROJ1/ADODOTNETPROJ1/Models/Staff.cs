﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODOTNETPROJ1.Models
{
    class Staff
    {
        public int Id { get; set; }
        public string StaffName { get; set; }
        public string Experience { get; set; }
        public string CID { get; set; }
    }
}
