﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;

namespace ADODOTNETPROJ1.Models
{
    class StaffLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["studb"]
            .ConnectionString;

        public List<Staff> getStaffDetails()
        {
            List<Staff> li = new List<Staff>();
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                string sql = "select * from Staff";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Staff s = new Staff();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.StaffName = reader.GetValue(1).ToString();
                    s.Experience = reader.GetValue(2).ToString();
                    s.CID = reader.GetValue(3).ToString();
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        public string AddData(Staff staff)
        {
            string message = "";

            string sql = String.Format("insert into Staff(StaffName, Experience, CID) " +
                "values('{0}',{1},{2})", 
                staff.StaffName, staff.Experience, staff.CID);


            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                message = "the record insert successfully" + staff.ToString();

            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public DataSet GetSearchData(int id)
        {

            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Staff where Id= " + id.ToString();

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public string DeleteData(int id)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sproc_deleteStaff", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                cmd.ExecuteNonQuery();
                message = "Data deleted successfully";
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public string Updatedata(Staff s)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sproc_update1", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = s.Id;
                cmd.Parameters.Add("@staffname", SqlDbType.VarChar, 50).Value = s.StaffName;
                cmd.Parameters.Add("@experience", SqlDbType.Int).Value = s.Experience;
                cmd.Parameters.Add("@cid", SqlDbType.Int).Value = s.CID;

                cmd.ExecuteNonQuery();
                msg = "Data updated successfully";
            }
            catch (Exception e)
            {
                msg = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return msg;
        }
    }
}
