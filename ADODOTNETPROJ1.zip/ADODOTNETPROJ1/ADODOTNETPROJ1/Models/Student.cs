﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODOTNETPROJ1.Models
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public float Fees { get; set; }
        public float Percent { get; set; }

        public override string ToString()
        {
            string str = "";
            str += " NAME " + Name;
            str += " Email " + Email;
            str += " Phone " + Phone;
            str += " Fees " + Fees.ToString();
            str += " Percent " + Percent.ToString();
            return str;
        }
    }
}
