﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Details button
        private void btn1_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }
        //insert button
        private void btn2_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            SearchForm ob = new SearchForm();
            ob.Show();
            this.Hide();
        }
        //DB DETAILS
        private void button1_Click(object sender, EventArgs e)
        {
            DbDetails ob = new DbDetails();
            ob.Show();
            this.Hide();
        }
        //update Deatils
        private void btn4_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            Deletedata ob = new Deletedata();
            ob.Show();
            this.Hide();
        }

        private void mToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Deletedata ob = new Deletedata();
            ob.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANK YOU FRO VISITING");
            Application.Exit();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchForm ob = new SearchForm();
            ob.Show();
            this.Hide();
        }

        private void searchByPercentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchPercent ob = new SearchPercent();
            ob.Show();
            this.Hide();
        }

        private void hOMEPAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HomePage ob = new HomePage();
            ob.Show();
            this.Hide();
        }
    }
}
