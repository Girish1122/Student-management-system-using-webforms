﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class SearchPercent : Form
    {
        StudentLogic ob = new StudentLogic();
        public SearchPercent()
        {
            InitializeComponent();
        }

        private void SearchPercent_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float per = float.Parse(txtPer.Text);
            dataGridView1.DataSource = ob.getSearchByPercent(per);
        }
    }
}
