﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class StaffSearch : Form
    {
        public StaffSearch()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value);
            StaffLogic ob = new StaffLogic();
            dataGridView1.DataSource = ob.GetSearchData(id).Tables[0];
            dataGridView1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 ob = new Form2();
            ob.Show();
            this.Hide();
        }

        private void insertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Show();

        }

        private void dDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sdetails ob = new Sdetails();
            ob.Show();
            this.Hide();

        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffUpdate ob = new StaffUpdate();
            ob.Show();
            this.Hide();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffDelete ob = new StaffDelete();
            ob.Show();
            this.Hide();
        }
    }
}
