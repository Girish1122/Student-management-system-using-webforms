﻿create procedure sproc_update1
(
@id int,
@staffname varchar(50),
@experience int,
@cid int

)
as
begin
 update Staff
 set StaffName=@staffname,Experience=@experience,CID=@cid
 where Id=@id;
 end